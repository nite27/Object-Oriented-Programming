
#  Java Railway Simulation Graphics Program

## 📌 Project Overview

The **Java Railway Simulation Graphics Program** is an interactive desktop graphics application developed using **Java Swing** and **Java AWT**. The project simulates a moving train environment with smooth animation, railway tracks, signal systems, sky effects, clouds, trees, and user controls.

This project demonstrates the use of:

* Object-Oriented Programming (OOP)
* Java Graphics and Animation
* Java Swing GUI Components
* Event Handling
* Keyboard Controls
* Real-Time Simulation
* Timer-Based Animation

The program is designed for beginners and educational purposes, making it easy to understand and modify.

---

#  Main Features

##  Train Animation

* One engine with multiple coaches
* Smooth train movement
* Animated rotating wheels
* Forward and reverse direction support
* Real-time speed changes

##  Railway Environment

* Circular railway track
* Railway sleepers
* Station platform
* Signal light system
* Electric poles
* Trees and landscape
* Moving clouds

##  Day and Night System

* Dynamic sky color changes
* Sun animation in daytime
* Moon animation in nighttime
* Toggle mode anytime during runtime

##  User Controls

### Buttons Available

| Button  | Function                |
| ------- | ----------------------- |
| Start   | Starts train animation  |
| Stop    | Stops train movement    |
| Pause   | Pauses animation        |
| Resume  | Resumes animation       |
| Reverse | Changes train direction |
| Speed + | Increases speed         |
| Speed - | Decreases speed         |
| Reset   | Resets simulation       |
| Exit    | Closes application      |

---

#  Keyboard Shortcuts

| Key   | Action                   |
| ----- | ------------------------ |
| Space | Start or Pause Animation |
| R     | Reverse Train Direction  |
| D     | Toggle Day/Night Mode    |

---

#  Technologies Used

| Technology   | Purpose              |
| ------------ | -------------------- |
| Java         | Programming Language |
| Java Swing   | GUI Design           |
| Java AWT     | Graphics and Drawing |
| Timer Class  | Animation Control    |
| OOP Concepts | Program Structure    |

---

#  Project Folder Structure

```text
Java Railway Simulation Graphics Program/
│
├── README.md
│
├── src/
│   ├── Main.java
│   ├── AnimationPanel.java
│   ├── ControlPanel.java
│   ├── Train.java
│   ├── Engine.java
│   ├── Coach.java
│   ├── Track.java
│   ├── TrainComponent.java
│   │
│   ├── Main.class
│   ├── AnimationPanel.class
│   ├── ControlPanel.class
│   ├── Train.class
│   ├── Engine.class
│   ├── Coach.class
│   ├── Track.class
│   └── TrainComponent.class
│
└── assets/ (optional future images or sounds)
```

---

#  File Explanation

## 1️ Main.java

### Purpose

This is the main entry point of the application.

### Responsibilities

* Creates the main application window
* Loads animation panel
* Loads control panel
* Sets frame size and visibility

---

## 2️ AnimationPanel.java

### Purpose

Handles all graphics rendering and animations.

### Responsibilities

* Draws sky and background
* Draws train and railway track
* Controls animation timer
* Handles keyboard input
* Draws clouds, trees, sun, moon, and signals

---

## 3️ ControlPanel.java

### Purpose

Creates all control buttons.

### Responsibilities

* Start button
* Pause button
* Resume button
* Reverse button
* Speed control buttons
* Reset button
* Exit button

---

## 4️ Train.java

### Purpose

Controls train movement and train logic.

### Responsibilities

* Updates train position
* Controls speed
* Handles direction changes
* Draws entire train

---

## 5️ Engine.java

### Purpose

Represents the locomotive engine.

### Responsibilities

* Draws engine body
* Draws engine wheels
* Engine animation effects

---

## 6️ Coach.java

### Purpose

Represents train coaches.

### Responsibilities

* Draws coach body
* Draws windows and wheels
* Maintains spacing between coaches

---

## 7 Track.java

### Purpose

Draws railway track graphics.

### Responsibilities

* Circular track rendering
* Railway sleepers
* Track color effects

---

#  Program Workflow

```text
Program Starts
       ↓
Main Window Opens
       ↓
Animation Timer Starts
       ↓
Track and Environment Draw
       ↓
Train Moves on Track
       ↓
User Controls Animation
       ↓
Day/Night and Direction Change
       ↓
Program Ends
```

---

#  System Requirements

## Minimum Requirements

| Component        | Requirement                   |
| ---------------- | ----------------------------- |
| Operating System | Windows / Linux / macOS       |
| RAM              | 2 GB                          |
| Java Version     | JDK 8 or Above                |
| IDE              | VS Code / IntelliJ / NetBeans |

---

# ⚙ Installation Guide

## Step 1: Install Java JDK

Download and install Java JDK:

* Recommended Version: JDK 17 or higher
* Verify installation using:

```bash
java -version
```

---

## Step 2: Extract Project Folder

Extract:

```text
Java Railway Simulation Graphics Program.zip
```

---

## Step 3: Open in VS Code

1. Open VS Code
2. Click:

```text
File → Open Folder
```

3. Select:

```text
Java Railway Simulation Graphics Program
```

---

# ▶ How to Run the Program

## Method 1: Using Terminal

### Compile Program

```bash
javac src/*.java
```

### Run Program

```bash
java -cp src Main
```

---

## Method 2: Using VS Code

1. Open project folder
2. Install Java Extension Pack
3. Open `Main.java`
4. Click ▶ Run Button

---

#  Graphics Included

The simulation includes many graphical components:

* Animated Train
* Railway Track
* Clouds
* Trees
* Station Area
* Signal Lights
* Poles
* Day Sky
* Night Sky
* Sun and Moon
* Ground and Grass

---

#  OOP Concepts Used

| OOP Concept    | Usage                |
| -------------- | -------------------- |
| Class          | Separate components  |
| Object         | Train, Track, Coach  |
| Encapsulation  | Data management      |
| Inheritance    | Graphics components  |
| Abstraction    | Simplified structure |
| Modular Design | Easy maintenance     |

---

#  Future Improvements

Future upgrades can include:

* Sound effects
* Railway station announcements
* Multiple trains
* Collision detection
* Passenger animation
* Real map system
* 3D graphics version
* Database integration
* Multiplayer simulation

---

# 🛠 Troubleshooting

## Problem: Java Not Found

### Solution

Install Java JDK and add Java to system PATH.

---

## Problem: Compilation Error

### Solution

Make sure all `.java` files are inside the `src` folder.

---

## Problem: Window Not Opening

### Solution

Check Java version compatibility.

---

#  Recommended Screenshots for Submission

You can include screenshots of:

1. Main Program Window
2. Train Moving Animation
3. Day Mode
4. Night Mode
5. Control Buttons
6. Reverse Direction Feature
7. Speed Control Feature

---

#  Educational Learning Outcomes

This project helps students learn:

* Java GUI Programming
* Graphics Rendering
* Animation Techniques
* Event Handling
* OOP Programming
* Java Swing Components
* Real-Time Simulation
* Interactive Applications

---


#  Author Information

## Project Title

**Java Railway Simulation Graphics Program**

## Developed Using

* Java Swing
* Java AWT
* OOP Concepts

---

#  Conclusion

The **Java Railway Simulation Graphics Program** is a beginner-friendly yet visually attractive graphics project that demonstrates animation, graphical rendering, and interactive controls using Java.

The project is clean, modular, easy to understand, and suitable for:

* University Assignments
* Graphics Programming Practice
* OOP Learning
* Java Swing Projects
* Portfolio Projects

This application provides both educational value and visual interaction through a complete railway simulation environment.

---

# Thank You

Thank you for using this Railway Simulation Graphics Program.

 Happy Coding with Java!
