import java.awt.*;

public abstract class TrainComponent {
    private final Color bodyColor;
    private final Color windowColor;
    private final Color detailColor;

    public TrainComponent(Color bodyColor, Color windowColor, Color detailColor) {
        this.bodyColor = bodyColor;
        this.windowColor = windowColor;
        this.detailColor = detailColor;
    }

    public Color getBodyColor() {
        return bodyColor;
    }

    public Color getWindowColor() {
        return windowColor;
    }

    public Color getDetailColor() {
        return detailColor;
    }

    public abstract void draw(Graphics2D g2, int x, int y, double wheelRotation, boolean headlightOn);
}
