import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class ControlPanel extends JPanel {
    public ControlPanel(AnimationPanel animationPanel) {
        setBackground(new Color(38, 52, 79));
        setLayout(new GridBagLayout());
        setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        addButton("Start", animationPanel::startAnimation, gbc, 0, 0);
        addButton("Stop", animationPanel::stopAnimation, gbc, 1, 0);
        addButton("Pause", animationPanel::pauseAnimation, gbc, 2, 0);
        addButton("Resume", animationPanel::resumeAnimation, gbc, 3, 0);
        addButton("Slow", animationPanel::setSpeedSlow, gbc, 0, 1);
        addButton("Medium", animationPanel::setSpeedMedium, gbc, 1, 1);
        addButton("Fast", animationPanel::setSpeedFast, gbc, 2, 1);
        addButton("Reverse", animationPanel::reverseDirection, gbc, 3, 1);
        addButton("Reset", animationPanel::resetSimulation, gbc, 0, 2);
        addButton("Day/Night", animationPanel::toggleDayNight, gbc, 1, 2);
        addButton("Exit", this::exitApplication, gbc, 2, 2);

        JLabel instructions = new JLabel("Keyboard: Space=Start/Pause, R=Reverse, D=Day/Night");
        instructions.setForeground(Color.WHITE);
        instructions.setFont(new Font("SansSerif", Font.PLAIN, 12));
        gbc.gridwidth = 4;
        gbc.gridx = 0;
        gbc.gridy = 3;
        add(instructions, gbc);
    }

    private void addButton(String text, Runnable action, GridBagConstraints gbc, int x, int y) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(70, 100, 170));
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.addActionListener((ActionEvent e) -> action.run());
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = 1;
        add(button, gbc);
    }

    private void exitApplication() {
        Window window = SwingUtilities.getWindowAncestor(this);
        if (window != null) {
            window.dispose();
        }
        System.exit(0);
    }
}
