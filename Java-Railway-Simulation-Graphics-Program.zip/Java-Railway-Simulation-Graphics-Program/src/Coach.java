import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class Coach extends TrainComponent {
    public Coach(Color bodyColor, Color windowColor, Color detailColor) {
        super(bodyColor, windowColor, detailColor);
    }

    @Override
    public void draw(Graphics2D g2, int x, int y, double wheelRotation, boolean headlightOn) {
        int width = 160;
        int height = 54;
        int wheelSize = 18;

        g2.setColor(getBodyColor());
        g2.fill(new RoundRectangle2D.Double(x, y, width, height, 14, 14));

        g2.setColor(getDetailColor());
        g2.fillRect(x + 4, y + 6, width - 8, 14);

        g2.setColor(getWindowColor());
        for (int i = 0; i < 3; i++) {
            g2.fillRect(x + 16 + i * 40, y + 14, 28, 18);
        }
        g2.setColor(Color.DARK_GRAY);
        g2.fillRect(x + 62, y + height - 12, 20, 12);

        g2.setColor(Color.BLACK);
        g2.draw(new RoundRectangle2D.Double(x, y, width, height, 14, 14));

        drawWheel(g2, x + 24, y + height - 4, wheelSize, wheelRotation);
        drawWheel(g2, x + 74, y + height - 4, wheelSize, wheelRotation);
        drawWheel(g2, x + 124, y + height - 4, wheelSize, wheelRotation);
    }

    private void drawWheel(Graphics2D g2, int x, int y, int size, double rotation) {
        g2.setColor(Color.BLACK);
        g2.fillOval(x, y, size, size);
        g2.setColor(Color.GRAY);
        g2.fillOval(x + 3, y + 3, size - 6, size - 6);
        g2.setColor(Color.DARK_GRAY);
        g2.translate(x + size / 2.0, y + size / 2.0);
        g2.rotate(rotation);
        g2.setStroke(new BasicStroke(1.8f));
        g2.drawLine(0, 0, size / 2 - 4, 0);
        g2.drawLine(0, 0, 0, size / 2 - 4);
        g2.drawLine(0, 0, -(size / 2 - 4), 0);
        g2.drawLine(0, 0, 0, -(size / 2 - 4));
        g2.rotate(-rotation);
        g2.translate(-(x + size / 2.0), -(y + size / 2.0));
    }
}
