import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Railway Simulation Graphics Program");
            frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            frame.setLayout(new BorderLayout());

            AnimationPanel animationPanel = new AnimationPanel();
            ControlPanel controlPanel = new ControlPanel(animationPanel);

            frame.add(animationPanel, BorderLayout.CENTER);
            frame.add(controlPanel, BorderLayout.SOUTH);
            frame.pack();
            frame.setMinimumSize(new Dimension(1080, 720));
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
            animationPanel.requestFocusInWindow();
        });
    }
}
