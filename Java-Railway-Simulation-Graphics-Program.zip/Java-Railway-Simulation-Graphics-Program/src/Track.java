import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;

public class Track {
    public void drawTrack(Graphics2D g2, int panelWidth, int panelHeight, boolean nightMode) {
        int left = 80;
        int right = Math.max(panelWidth - 80, 620);
        int trackTop = panelHeight - 180;
        int railDistance = 32;
        int railThickness = 14;

        Color bedColor = nightMode ? new Color(48, 48, 48) : new Color(76, 76, 76);
        Color ballastColor = nightMode ? new Color(70, 70, 70) : new Color(110, 110, 110);
        Color sleeperColor = nightMode ? new Color(120, 90, 60) : new Color(150, 110, 70);

        g2.setColor(bedColor);
        g2.fillRoundRect(left - 20, trackTop - 18, right - left + 40, 90, 24, 24);

        g2.setColor(ballastColor);
        g2.fillRoundRect(left, trackTop, right - left, 50, 18, 18);

        g2.setColor(new Color(155, 155, 155));
        g2.fillRect(left, trackTop + 10, right - left, railThickness);
        g2.fillRect(left, trackTop + 10 + railDistance, right - left, railThickness);

        drawSleepers(g2, left, trackTop, right, railDistance, sleeperColor);
    }

    private void drawSleepers(Graphics2D g2, int left, int trackTop, int right, int railDistance, Color sleeperColor) {
        g2.setColor(sleeperColor);
        int sleeperWidth = 40;
        int sleeperHeight = 12;
        int start = left + 10;
        int end = right - 10;
        int spacing = 60;
        int y = trackTop + 18;

        for (int x = start; x <= end; x += spacing) {
            g2.fillRoundRect(x, y, sleeperWidth, sleeperHeight, 8, 8);
        }
    }
}
