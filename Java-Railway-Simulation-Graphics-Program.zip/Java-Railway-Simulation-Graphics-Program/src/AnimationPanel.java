import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class AnimationPanel extends JPanel {
    private final Train train;
    private final Track track;
    private Timer timer;
    private boolean paused;
    private boolean nightMode;
    private double cloudOffset;
    private int signalFrame;

    public AnimationPanel() {
        train = new Train();
        track = new Track();
        setPreferredSize(new Dimension(1100, 720));
        setBackground(new Color(135, 206, 235));
        setFocusable(true);
        setupTimer();
        installKeyBindings();
    }

    private void setupTimer() {
        timer = new Timer(24, e -> {
            train.update(getWidth(), getHeight());
            cloudOffset += 1.2;
            if (cloudOffset > getWidth() + 150) {
                cloudOffset = -260;
            }
            signalFrame = (signalFrame + 1) % 80;
            repaint();
        });
    }

    private void installKeyBindings() {
        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_SPACE, 0), "toggleStartPause");
        getActionMap().put("toggleStartPause", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (train.isMoving() && !paused) {
                    pauseAnimation();
                } else {
                    startAnimation();
                }
            }
        });
        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_R, 0), "reverseDirection");
        getActionMap().put("reverseDirection", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                reverseDirection();
            }
        });
        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_D, 0), "toggleDayNight");
        getActionMap().put("toggleDayNight", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                toggleDayNight();
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        drawSky(g2);
        drawBackground(g2);
        track.drawTrack(g2, getWidth(), getHeight(), nightMode);
        drawStationArea(g2);
        drawSignal(g2);
        drawClouds(g2);
        train.draw(g2, getWidth(), getHeight());
        drawOverlay(g2);
        g2.dispose();
    }

    private void drawSky(Graphics2D g2) {
        Color top = nightMode ? new Color(18, 22, 55) : new Color(135, 206, 235);
        Color bottom = nightMode ? new Color(28, 33, 72) : new Color(175, 221, 255);
        g2.setPaint(new GradientPaint(0, 0, top, 0, getHeight(), bottom));
        g2.fillRect(0, 0, getWidth(), getHeight());

        if (nightMode) {
            drawMoon(g2);
        } else {
            drawSun(g2);
        }
    }

    private void drawSun(Graphics2D g2) {
        g2.setColor(new Color(255, 230, 100));
        g2.fillOval(getWidth() - 180, 40, 120, 120);
    }

    private void drawMoon(Graphics2D g2) {
        g2.setColor(new Color(240, 240, 255));
        g2.fillOval(getWidth() - 170, 50, 100, 100);
        g2.setColor(new Color(18, 22, 55));
        g2.fillOval(getWidth() - 150, 62, 80, 80);
    }

    private void drawClouds(Graphics2D g2) {
        g2.setColor(nightMode ? new Color(190, 190, 210, 200) : new Color(255, 255, 255, 220));
        for (int i = 0; i < 4; i++) {
            int x = (int) ((cloudOffset + i * 220) % (getWidth() + 260)) - 120;
            int y = 80 + (i % 2) * 30;
            g2.fillOval(x, y, 120, 40);
            g2.fillOval(x + 30, y - 16, 90, 50);
            g2.fillOval(x + 60, y, 120, 40);
        }
    }

    private void drawBackground(Graphics2D g2) {
        int height = getHeight();
        g2.setColor(nightMode ? new Color(12, 25, 50) : new Color(96, 180, 92));
        g2.fillRect(0, height - 160, getWidth(), 160);

        drawMountains(g2);
        drawTrees(g2);
        drawPoles(g2);
    }

    private void drawMountains(Graphics2D g2) {
        int base = getHeight() - 150;
        g2.setColor(new Color(90, 90, 110));
        int[] xPoints = {40, 220, 380};
        int[] yPoints = {base, base - 120, base};
        g2.fillPolygon(xPoints, yPoints, 3);
        int[] xPoints2 = {180, 420, 620};
        int[] yPoints2 = {base, base - 160, base};
        g2.fillPolygon(xPoints2, yPoints2, 3);
        g2.setColor(new Color(125, 125, 145));
        int[] xPoints3 = {520, 760, 940};
        int[] yPoints3 = {base, base - 140, base};
        g2.fillPolygon(xPoints3, yPoints3, 3);
    }

    private void drawTrees(Graphics2D g2) {
        for (int i = 0; i < 8; i++) {
            int x = 60 + i * 140;
            int y = getHeight() - 190;
            g2.setColor(new Color(80, 48, 30));
            g2.fillRect(x + 6, y + 34, 12, 40);
            g2.setColor(new Color(45, 120, 40));
            g2.fillOval(x - 20, y, 60, 50);
            g2.fillOval(x - 10, y - 20, 40, 50);
            g2.fillOval(x - 30, y + 10, 60, 40);
        }
    }

    private void drawPoles(Graphics2D g2) {
        int height = getHeight();
        g2.setColor(new Color(70, 70, 70));
        for (int i = 0; i < 5; i++) {
            int x = 160 + i * 180;
            g2.fillRect(x, height - 260, 8, 140);
            g2.setStroke(new BasicStroke(3f));
            g2.drawLine(x + 4, height - 252, x + 36, height - 228);
            g2.drawLine(x + 4, height - 238, x + 36, height - 214);
        }
    }

    private void drawStationArea(Graphics2D g2) {
        int base = getHeight() - 160;
        g2.setColor(new Color(180, 180, 180));
        g2.fillRect(60, base - 80, 360, 80);
        g2.setColor(new Color(220, 250, 255));
        g2.fillRect(80, base - 72, 320, 48);
        g2.setColor(new Color(120, 120, 140));
        g2.fillRect(60, base - 16, 360, 16);
        g2.setColor(new Color(90, 40, 20));
        g2.setFont(new Font("SansSerif", Font.BOLD, 20));
        g2.drawString("RIVERDALE STATION", 86, base - 38);

        g2.setColor(new Color(255, 255, 255));
        g2.fillRect(110, base - 44, 18, 24);
        g2.fillRect(150, base - 44, 18, 24);
        g2.fillRect(190, base - 44, 18, 24);

        g2.setColor(new Color(160, 90, 40));
        g2.fillRect(310, base - 60, 90, 20);
        g2.setColor(Color.WHITE);
        g2.drawString("BOARD", 324, base - 45);

        g2.setColor(new Color(50, 50, 80));
        g2.fillRect(150, base - 18, 100, 14);
        g2.fillRect(280, base - 18, 54, 14);
        g2.setColor(new Color(200, 200, 210));
        g2.fillOval(160, base - 40, 20, 12);
        g2.fillOval(210, base - 44, 26, 16);
    }

    private void drawSignal(Graphics2D g2) {
        int x = getWidth() - 160;
        int base = getHeight() - 190;
        g2.setColor(new Color(55, 55, 55));
        g2.fillRect(x, base - 100, 16, 110);
        g2.setColor(new Color(30, 30, 30));
        g2.fillRect(x - 14, base - 108, 44, 28);

        boolean green = signalFrame < 40;
        g2.setColor(green ? new Color(60, 200, 90) : new Color(70, 70, 70));
        g2.fillOval(x - 4, base - 96, 20, 20);
        g2.setColor(!green ? new Color(220, 80, 80) : new Color(70, 70, 70));
        g2.fillOval(x - 4, base - 68, 20, 20);
    }

    private void drawOverlay(Graphics2D g2) {
        g2.setColor(new Color(255, 255, 255, 190));
        g2.fillRoundRect(20, 20, 260, 110, 18, 18);
        g2.setColor(Color.DARK_GRAY);
        g2.setFont(new Font("SansSerif", Font.BOLD, 14));
        g2.drawString("Railway Simulation Controls", 36, 44);
        g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
        g2.drawString("Space: Start/Pause", 36, 68);
        g2.drawString("R: Reverse Direction", 36, 88);
        g2.drawString("D: Day/Night Toggle", 36, 108);
    }

    public void startAnimation() {
        train.setMoving(true);
        paused = false;
        if (!timer.isRunning()) {
            timer.start();
        }
    }

    public void stopAnimation() {
        train.setMoving(false);
        paused = false;
        if (timer.isRunning()) {
            timer.stop();
        }
        repaint();
    }

    public void pauseAnimation() {
        paused = true;
        if (timer.isRunning()) {
            timer.stop();
        }
    }

    public void resumeAnimation() {
        if (!train.isMoving()) {
            train.setMoving(true);
        }
        paused = false;
        if (!timer.isRunning()) {
            timer.start();
        }
    }

    public void setSpeedSlow() {
        train.setSpeed(1.8);
    }

    public void setSpeedMedium() {
        train.setSpeed(3.8);
    }

    public void setSpeedFast() {
        train.setSpeed(6.2);
    }

    public void reverseDirection() {
        train.reverseDirection();
    }

    public void resetSimulation() {
        train.reset();
        nightMode = false;
        pauseAnimation();
        repaint();
    }

    public void toggleDayNight() {
        nightMode = !nightMode;
        repaint();
    }
}
