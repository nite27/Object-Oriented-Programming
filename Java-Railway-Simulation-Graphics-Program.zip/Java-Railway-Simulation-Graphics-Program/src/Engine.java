import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class Engine extends TrainComponent {
    public Engine(Color bodyColor, Color windowColor, Color detailColor) {
        super(bodyColor, windowColor, detailColor);
    }

    @Override
    public void draw(Graphics2D g2, int x, int y, double wheelRotation, boolean headlightOn) {
        int width = 180;
        int height = 60;
        int wheelSize = 22;

        g2.setColor(getBodyColor());
        g2.fill(new RoundRectangle2D.Double(x, y, width, height, 16, 16));

        g2.setColor(getDetailColor());
        g2.fillRect(x + 12, y - 24, 40, 24); // chimney
        g2.fillRect(x + 28, y - 14, 20, 14);
        g2.fillRect(x + 18, y + 4, 36, 10);

        g2.setColor(getWindowColor());
        g2.fillRect(x + 90, y + 10, 24, 20);
        g2.fillRect(x + 124, y + 10, 24, 20);

        g2.setColor(Color.DARK_GRAY);
        g2.fillRect(x + 10, y + height - 12, width - 20, 12);

        if (headlightOn) {
            g2.setColor(new Color(255, 255, 180, 170));
            g2.fillOval(x + width - 16, y + 12, 20, 20);
        }

        g2.setColor(Color.BLACK);
        g2.draw(new RoundRectangle2D.Double(x, y, width, height, 16, 16));

        drawWheel(g2, x + 28, y + height - 4, wheelSize, wheelRotation);
        drawWheel(g2, x + 78, y + height - 4, wheelSize, wheelRotation);
        drawWheel(g2, x + 128, y + height - 4, wheelSize, wheelRotation);
    }

    private void drawWheel(Graphics2D g2, int x, int y, int size, double rotation) {
        g2.setColor(Color.BLACK);
        g2.fillOval(x, y, size, size);
        g2.setColor(Color.LIGHT_GRAY);
        g2.fillOval(x + 4, y + 4, size - 8, size - 8);
        g2.setColor(Color.DARK_GRAY);
        g2.translate(x + size / 2.0, y + size / 2.0);
        g2.rotate(rotation);
        g2.setStroke(new BasicStroke(2f));
        g2.drawLine(0, 0, size / 2 - 4, 0);
        g2.drawLine(0, 0, 0, size / 2 - 4);
        g2.drawLine(0, 0, -(size / 2 - 4), 0);
        g2.drawLine(0, 0, 0, -(size / 2 - 4));
        g2.rotate(-rotation);
        g2.translate(-(x + size / 2.0), -(y + size / 2.0));
    }
}
