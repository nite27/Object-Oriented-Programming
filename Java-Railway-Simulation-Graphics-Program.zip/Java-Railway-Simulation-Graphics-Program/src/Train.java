import java.awt.*;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;
import java.util.List;

public class Train {
    private final Engine engine;
    private final List<Coach> coaches;
    private double location;
    private double speed;
    private double wheelRotation;
    private boolean moving;
    private boolean forwardDirection;

    public Train() {
        engine = new Engine(new Color(200, 50, 50), new Color(160, 220, 250), new Color(230, 180, 60));
        coaches = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            coaches.add(new Coach(new Color(30, 120, 190), new Color(210, 245, 255), new Color(255, 255, 255)));
        }
        speed = 3.8;
        wheelRotation = 0;
        location = 0.0;
        moving = false;
        forwardDirection = true;
    }

    public void update(int panelWidth, int panelHeight) {
        if (moving) {
            double pathLeft = 120;
            double pathRight = Math.max(panelWidth - 120, 620);
            double direction = forwardDirection ? 1.0 : -1.0;
            location += speed * direction;
            wheelRotation += speed * 0.10 * direction;
            if (location > pathRight + 160) {
                location = pathLeft - 180;
            } else if (location < pathLeft - 180) {
                location = pathRight + 160;
            }
        }
    }

    public void draw(Graphics2D g2, int panelWidth, int panelHeight) {
        int pathLeft = 120;
        int pathRight = Math.max(panelWidth - 120, 620);
        int y = panelHeight - 140;

        double engineX = location;
        double angle = forwardDirection ? 0 : Math.PI;
        drawComponent(g2, engine, engineX, y, angle, true);

        for (int i = 0; i < coaches.size(); i++) {
            double offset = (i + 1) * 145.0;
            double coachX = forwardDirection ? engineX - offset : engineX + offset;
            drawComponent(g2, coaches.get(i), coachX, y, angle, false);
        }
    }

    private void drawComponent(Graphics2D g2, TrainComponent component, double x, double y, double angle, boolean headlightOn) {
        AffineTransform old = g2.getTransform();
        g2.translate(x, y);
        g2.rotate(angle);
        component.draw(g2, -90, -30, wheelRotation, headlightOn);
        g2.setTransform(old);
    }

    public void setSpeed(double speed) {
        if (speed < 0.5) {
            this.speed = 0.5;
        } else {
            this.speed = speed;
        }
    }

    public double getSpeed() {
        return speed;
    }

    public void setMoving(boolean moving) {
        this.moving = moving;
    }

    public boolean isMoving() {
        return moving;
    }

    public void reverseDirection() {
        forwardDirection = !forwardDirection;
    }

    public void reset() {
        location = 0.0;
        wheelRotation = 0.0;
        moving = false;
        forwardDirection = true;
    }

    private double normalize(double value) {
        value %= 1.0;
        if (value < 0) {
            value += 1.0;
        }
        return value;
    }
}
